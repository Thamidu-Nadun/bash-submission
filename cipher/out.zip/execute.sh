#!/bin/bash
tr A-Za-z N-ZA-Mn-za-m<<<"$1"
